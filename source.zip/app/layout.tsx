import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "しあわせの木｜小さなやさしさを育てよう",
  description: "こころに、ひとこと。毎日に、小さなやさしさを。あなたのペースで育てる、しあわせの木。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}
