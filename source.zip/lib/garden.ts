export type Theme='自分をいたわる'|'一歩踏み出す'|'人とのつながり';
export type Word={id:string;text:string;theme:Theme;createdAt:number};
export type RecordDay={date:string;title:string;note:string;createdAt:number};
export type Garden={words:Word[];favorites:string[];records:RecordDay[];picks:Record<string,number>};
export const themes:Theme[]=['自分をいたわる','一歩踏み出す','人とのつながり'];
const texts:Record<Theme,string[]>={
'自分をいたわる':[
'小さな「できた」を、\n今日はひとつ見つけよう。',
'急がなくていい。\nあなたの歩幅で、進めばいい。',
'休む時間も、\n明日の自分を育てている。',
'うまくいかない日にも、\nあなたの大切さは変わらない。',
'全部できなくても大丈夫。\nできたことに、目を向けよう。',
'誰かと比べる前に、\n今日の自分をねぎらおう。',
'気持ちが晴れない日は、\n晴れないまま休んでもいい。',
'「ここまでよくやったね」を、\nまず自分に贈ろう。',
'気がついたら、肩の力を。\nひと息つく時間は、あなたのもの。',
'好きなものを好きと感じる。\nその気持ちを大切にしよう。',
'何もしない時間にも、\n心がほどける余白がある。',
'今日のあなたに必要なのは、\nもうひと頑張りより、ひと休みかも。'],
'一歩踏み出す':[
'大きく変わらなくてもいい。\n小さな一歩から、景色は変わる。',
'はじめてのことは、\n少しずつ慣れていけばいい。',
'迷った時間も、\n自分の答えを探した時間。',
'完璧な準備より、\n今日できる小さなことを。',
'昨日のやり方が合わなければ、\n今日は違う道を選んでいい。',
'できなかったことは、\n次に工夫できること。',
'途中で立ち止まっても、\n歩いてきた道は消えない。',
'「やってみたい」の気持ちを、\n小さく始めてみよう。',
'答えがまだなくても、\n考えている自分を信じてみよう。',
'今日の一歩は、\n未来の自分への小さな贈りもの。',
'予定どおりでなくても、\n今日見つけたものはある。',
'できるかどうかの前に、\n楽しそうかを感じてみよう。'],
'人とのつながり':[
'あなたの「ありがとう」が、\n誰かの一日をあたためる。',
'小さなやさしさは、\n目に見えないところにも残る。',
'話を最後まで聴くことも、\n大切な贈りものになる。',
'元気なふりをしなくても、\nつながっていていい。',
'助けてもらうことは、\n誰かを信頼することでもある。',
'「おつかれさま」の一言を、\n身近な人にも、自分にも。',
'思い出したあの人に、\n短い一言を届けてみよう。',
'一人で抱えなくていい。\n頼ることも、あなたの選択。',
'相手のよさに気づいたら、\n言葉にして渡してみよう。',
'やさしさは、\n自分にも向けていい。',
'同じでなくても、\n大切にし合うことはできる。',
'あなたがここにいることを、\nうれしく思う人がいる。']
};
export const builtin:Word[]=themes.flatMap((theme,t)=>texts[theme].map((text,i)=>({id:`b-${t}-${i}`,text,theme,createdAt:0})));
export const missions=[
{title:'「ありがとう」を、ひとつ届ける',description:'身近な人に、いつもより少し具体的に感謝を伝えてみましょう。',tag:'誰かへ',minutes:'1分'},
{title:'今日の自分を、ひとつ褒める',description:'朝起きたことでも、用事を済ませたことでも。小さな「できた」を見つけましょう。',tag:'自分へ',minutes:'1分'},
{title:'身のまわりを、ひとつ整える',description:'机の上のものをひとつ戻す。カップを片づける。できる範囲で十分です。',tag:'暮らしへ',minutes:'2分'},
{title:'誰かの話を、ゆっくり聴く',description:'結論を急がずに、最後まで。その時間を相手への贈りものに。',tag:'誰かへ',minutes:'3分'},
{title:'好きな飲みものを、ゆっくり味わう',description:'手を止めて、香りや温かさを感じる時間をつくりましょう。',tag:'自分へ',minutes:'3分'},
{title:'思い出した人に、一言を届ける',description:'「元気にしてる？」など短い言葉で。送りたい相手が浮かんだら。',tag:'誰かへ',minutes:'2分'},
{title:'空を見上げる時間をつくる',description:'窓からでも大丈夫。今日の空の色や雲を、少しだけ眺めてみましょう。',tag:'自分へ',minutes:'1分'},
{title:'「おつかれさま」を伝える',description:'家族や友人、一緒に働く人に。もちろん、自分に伝えてもいいですね。',tag:'誰かへ',minutes:'1分'},
{title:'好きな音楽を、一曲聴く',description:'何かをしながらでも、目を閉じても。自分が心地よい聴き方で。',tag:'自分へ',minutes:'3分'},
{title:'使った場所を、少しきれいにする',description:'洗面台をひと拭き、椅子を元の位置に。次の人が気持ちよく使えるように。',tag:'暮らしへ',minutes:'2分'},
{title:'身近な人のいいところを伝える',description:'「助かったよ」「その考え、いいね」。気づいたことを短い一言に。',tag:'誰かへ',minutes:'1分'},
{title:'今日うれしかったことを、ひとつ書く',description:'小さなことほど大歓迎。おいしい一口、きれいな色、あたたかな言葉。',tag:'自分へ',minutes:'2分'},
{title:'大切なものを、ひとつ手入れする',description:'よく使う靴やかばん、いつもの道具を少しだけ整えてみましょう。',tag:'暮らしへ',minutes:'3分'},
{title:'心地よい休憩を、自分に贈る',description:'画面から目を離し、楽な姿勢でひと休み。今日の自分に合う時間を。',tag:'自分へ',minutes:'2分'},
{title:'挨拶に、ひとこと添えてみる',description:'「おはよう」に「今日はいい天気ですね」。自然に言えそうなときだけで大丈夫。',tag:'誰かへ',minutes:'1分'},
{title:'自分の好きなところを見つける',description:'性格でも、続けていることでも。「こんなところ、悪くないな」をひとつ。',tag:'自分へ',minutes:'2分'},
{title:'水を大切に使う',description:'使っていないときの蛇口を閉めるなど、今日できる小さな工夫を。',tag:'暮らしへ',minutes:'1分'},
{title:'助けてくれた人を、思い出す',description:'今すぐ連絡しなくても大丈夫。思い浮かべて、心の中でありがとうを。',tag:'誰かへ',minutes:'1分'},
{title:'明日の自分が楽になる準備をする',description:'着るものを用意する、持ちものをまとめる。小さな準備をひとつ。',tag:'暮らしへ',minutes:'3分'},
{title:'好きな景色を、見つける',description:'道ばたの花、窓の光、いつもの街。目にとまったものを味わいましょう。',tag:'自分へ',minutes:'2分'},
{title:'できたことを、声に出してみる',description:'「今日はこれができた」。自分に聞こえるくらいの声でも、心の中でも。',tag:'自分へ',minutes:'1分'}
];
export const dayKey=(d=new Date())=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
export const hash=(s:string)=>Array.from(s).reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,7);
export const empty=():Garden=>({words:[],favorites:[],records:[],picks:{}});
export const uid=()=>'c-'+(typeof crypto.randomUUID==='function'?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join(''));
export function stageOf(n:number){return n>=14?3:n>=7?2:n>=3?1:0;}
export const stages=[{name:'芽ばえ',start:0,next:3,description:'小さな一歩から、育っていきます。'},{name:'すくすく',start:3,next:7,description:'あなたのやさしさが、葉を広げています。'},{name:'こもれび',start:7,next:14,description:'小さな積み重ねが、豊かな緑に。'},{name:'花ひらく',start:14,next:null,description:'あなたの歩幅で育てた木に、花が咲きました。'}];
export function validDate(s:unknown):s is string{return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&dayKey(new Date(s+'T12:00:00'))===s;}
const timestamp=(v:unknown)=>typeof v==='number'&&Number.isFinite(v)&&v>0&&v<=8640000000000000;
export function validateGarden(v:unknown):Garden{
if(!v||typeof v!=='object')throw new Error('バックアップの形式を確認してください。');
const g=v as Garden;
if(!Array.isArray(g.words)||g.words.length>3000||!g.words.every(w=>w&&typeof w.id==='string'&&/^c-[a-zA-Z0-9-]{1,70}$/.test(w.id)&&typeof w.text==='string'&&w.text.trim().length>0&&w.text.length<=180&&themes.includes(w.theme)&&timestamp(w.createdAt)))throw new Error('ことばのデータを読み込めません。');
if(!Array.isArray(g.records)||g.records.length>20000||!g.records.every(r=>r&&validDate(r.date)&&typeof r.title==='string'&&r.title.length>0&&r.title.length<=120&&typeof r.note==='string'&&r.note.length<=300&&timestamp(r.createdAt)))throw new Error('達成の記録を読み込めません。');
if(new Set(g.words.map(w=>w.id)).size!==g.words.length||new Set(g.records.map(r=>r.date)).size!==g.records.length)throw new Error('同じことば、または同じ日の記録が重複しています。');
if(!Array.isArray(g.favorites)||g.favorites.length>5000||!g.favorites.every(f=>typeof f==='string'&&f.length<=80))throw new Error('お気に入りの形式を確認してください。');
if(!g.picks||typeof g.picks!=='object'||Array.isArray(g.picks)||Object.keys(g.picks).length>20000||!Object.entries(g.picks).every(([d,n])=>validDate(d)&&Number.isInteger(n)&&n>=0&&n<missions.length))throw new Error('行動のデータを読み込めません。');
const ids=new Set([...builtin,...g.words].map(w=>w.id));
return {words:g.words.map(w=>({id:w.id,text:w.text.trim(),theme:w.theme,createdAt:w.createdAt})),records:g.records.map(r=>({date:r.date,title:r.title,note:r.note,createdAt:r.createdAt})),favorites:Array.from(new Set(g.favorites)).filter(f=>ids.has(f)),picks:Object.fromEntries(Object.entries(g.picks))};
}
export function parseBackup(text:string):Garden{let v;try{v=JSON.parse(text);}catch{throw new Error('JSONファイルを読み込めませんでした。');}if(v?.app!=='shiawase-tree'||v.version!==1)throw new Error('しあわせの木で書き出したバックアップを選んでください。');return validateGarden(v.data);}
export function exportText(g:Garden){return JSON.stringify({app:'shiawase-tree',version:1,exportedAt:new Date().toISOString(),data:g});}
export function mergeGarden(a:Garden,b:Garden):Garden{return validateGarden({words:Array.from(new Map([...a.words,...b.words].map(w=>[w.id,w])).values()),records:Array.from(new Map([...a.records,...b.records].map(r=>[r.date,r])).values()),favorites:Array.from(new Set([...a.favorites,...b.favorites])),picks:{...a.picks,...b.picks}});}
let connection:Promise<IDBDatabase>|null=null;
function database(){if(!connection)connection=new Promise((resolve,reject)=>{if(!globalThis.indexedDB){reject(new Error('このブラウザーでは保存できません。通常モードのChromeやSafariで開いてください。'));return;}const req=indexedDB.open('shiawase-tree-v1',1);req.onupgradeneeded=()=>req.result.createObjectStore('garden');req.onsuccess=()=>{req.result.onversionchange=()=>{req.result.close();connection=null;};resolve(req.result);};req.onerror=()=>{connection=null;reject(new Error('保存領域を開けません。ブラウザーの通常モードでお試しください。'));};req.onblocked=()=>{connection=null;reject(new Error('別のタブを閉じて、再読み込みしてください。'));};});return connection;}
export async function readGarden():Promise<Garden>{const db=await database();return new Promise((resolve,reject)=>{const req=db.transaction('garden').objectStore('garden').get('state');req.onsuccess=()=>{try{resolve(req.result?validateGarden(req.result):empty());}catch{reject(new Error('記録を読み込めませんでした。保存したバックアップをご確認ください。'));}};req.onerror=()=>reject(new Error('記録を読み込めませんでした。'));});}
export async function changeGarden(fn:(g:Garden)=>Garden):Promise<Garden>{const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction('garden','readwrite');const s=tx.objectStore('garden');const request=s.get('state');let updated:Garden;let error:unknown;request.onsuccess=()=>{try{updated=validateGarden(fn(request.result?validateGarden(request.result):empty()));s.put(updated,'state');}catch(e){error=e;tx.abort();}};tx.oncomplete=()=>{try{localStorage.setItem('shiawase-tree-changed',String(Date.now()));}catch{}resolve(updated);};tx.onabort=()=>reject(error||new Error('保存できませんでした。入力内容は残っています。'));tx.onerror=()=>reject(new Error('保存できませんでした。端末の空き容量をご確認ください。'));});}

