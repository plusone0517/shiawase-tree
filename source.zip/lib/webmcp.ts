import {readGarden,dayKey,stageOf,stages} from './garden';
type Tool={name:string;title:string;description:string;inputSchema:object;annotations:{readOnlyHint:boolean;untrustedContentHint:boolean};execute:(input:unknown)=>Promise<unknown>};
export function registerGardenTool(){
 const context=(document as Document&{modelContext?:{registerTool:(tool:Tool,options:{signal:AbortSignal})=>void|Promise<void>}}).modelContext;
 if(!context?.registerTool)return;
 const lifecycle=new AbortController();
 try{void Promise.resolve(context.registerTool({name:'read_garden_summary',title:'しあわせの木の記録を読む',description:'Read this browser’s current garden stage, total completed days, today’s record, and seven most recent records. Does not modify data.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},async execute(input){if(input===null||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length)throw new Error('Input must be an empty object.');const g=await readGarden();return {completedDays:g.records.length,stage:stages[stageOf(g.records.length)].name,favoriteCount:g.favorites.length,customWordCount:g.words.length,today:g.records.find(r=>r.date===dayKey())??null,recentRecords:[...g.records].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,7)};}},{signal:lifecycle.signal})).catch(()=>{});}catch{}
 return ()=>lifecycle.abort();
}
